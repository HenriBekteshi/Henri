package com.mycompany.bse1.hospitalsystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManagementService {

    public static File createPeopleFile(String directoryName, String fileName)
            throws IOException {
        if (directoryName == null || directoryName.trim().isEmpty()) {
            throw new IllegalArgumentException("Directory name cannot be empty!");
        }
        if (fileName == null || fileName.trim().isEmpty()) {
            throw new IllegalArgumentException("File name cannot be empty!");
        }

        File directory = new File(directoryName);
        if (!directory.exists() && !directory.mkdirs()) {
            throw new IOException("Could not create directory: " + directory.getAbsolutePath());
        }
        if (!directory.isDirectory()) {
            throw new IOException("Path is not a directory: " + directory.getAbsolutePath());
        }

        File peopleFile = new File(directory, fileName);
        if (!peopleFile.exists() && !peopleFile.createNewFile()) {
            throw new IOException("Could not create file: " + peopleFile.getAbsolutePath());
        }
        return peopleFile;
    }

    public static void printFileInfo(File file) {
        if (file == null) {
            System.out.println("File is null");
            return;
        }
        if (file.exists()) {
            System.out.println("File absolute path: " + file.getAbsolutePath());
            System.out.println("File name: " + file.getName());
            System.out.println("File size: " + file.length());
            System.out.println("File Read permissions: " + file.canRead());
            System.out.println("File Write permissions: " + file.canWrite() + "\n");
        } else {
            System.out.println("File doesn't exist\n" + file);
        }
    }

    public static void writePerson(File file, Person person, boolean append)
            throws IOException {
        if (file == null || person == null) {
            throw new IllegalArgumentException("File and person are required!");
        }
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Could not create parent directory.");
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, append))) {
            bw.write(person.getFileLine());
            bw.newLine();
        }
        System.out.println("Finished writing into the file\n");
    }

    public static Person[] readFile(File file) throws IOException {
        if (file == null || !file.exists()) {
            throw new FileNotFoundException(
                    "File doesn't exist: " + (file == null ? "null" : file.getAbsolutePath()));
        }

        List<Person> people = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;

            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] fields = line.split(",", -1);
                if (fields.length != 4) {
                    throw new IOException("Invalid person data at line " + lineNumber
                            + ": expected 4 fields.");
                }

                try {
                    int age = Integer.parseInt(fields[2].trim());
                    people.add(new Person(fields[0].trim(), fields[1].trim(),
                            age, fields[3].trim()));
                } catch (IllegalArgumentException ex) {
                    throw new IOException("Invalid person data at line "
                            + lineNumber + ": " + ex.getMessage(), ex);
                }
            }
        }

        Person[] peopleArray = people.toArray(new Person[0]);
        for (Person person : peopleArray) {
            System.out.println(person);
        }
        return peopleArray;
    }
}
