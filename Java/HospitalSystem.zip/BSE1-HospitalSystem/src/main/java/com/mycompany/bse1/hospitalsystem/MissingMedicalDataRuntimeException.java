/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse1.hospitalsystem;

/**
 *
 * @author Bachelor
 */
//define a user custom runtime exception
public class MissingMedicalDataRuntimeException extends RuntimeException{
    
    public MissingMedicalDataRuntimeException(String exceptionMessage){
        super(exceptionMessage);
    }
}
