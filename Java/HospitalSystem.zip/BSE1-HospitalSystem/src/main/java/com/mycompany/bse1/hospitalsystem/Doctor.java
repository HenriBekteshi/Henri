package com.mycompany.bse1.hospitalsystem;

public class Doctor extends MedicalStaff {

    private String specialization;
    private String availableDays;
    private int availableSlots;

    public Doctor(String name, String surname, int age, String gender,
            String department, String specialization,
            String availableDays, int availableSlots) {
        super(name, surname, age, gender, department);
        setSpecialization(specialization);
        setAvailableDays(availableDays);
        setAvailableSlots(availableSlots);
    }

    public Doctor(Person person, String department, String specialization,
            String availableDays, int availableSlots) {
        super(person, department);
        setSpecialization(specialization);
        setAvailableDays(availableDays);
        setAvailableSlots(availableSlots);
    }

    public String getSpecialization() { return specialization; }

    public void setSpecialization(String specialization) {
        if (specialization == null || specialization.trim().isEmpty()) {
            throw new IllegalArgumentException("Specialization cannot be null or empty!");
        }
        this.specialization = specialization.trim();
    }

    public String getAvailableDays() { return availableDays; }

    public void setAvailableDays(String availableDays) {
        if (availableDays == null || availableDays.trim().isEmpty()) {
            throw new IllegalArgumentException("Available days cannot be null or empty!");
        }
        this.availableDays = availableDays.trim();
    }

    public int getAvailableSlots() { return availableSlots; }

    public void setAvailableSlots(int availableSlots) {
        if (availableSlots < 0) {
            throw new IllegalArgumentException("Available slots cannot be negative!");
        }
        this.availableSlots = availableSlots;
    }

    @Override
    public String toString() {
        return "Doctor{" + super.toString()
                + "\nspecialization=" + specialization
                + "\navailable days=" + availableDays
                + "\navailable slots=" + availableSlots + "}\n";
    }

    @Override
    public void performDuty(AppointmentManager appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null!");
        }
        if (appointment.getPatient() == null || appointment.getAssignedDoctorObject() != this) {
            throw new IllegalArgumentException("Appointment is not assigned to this doctor or has no patient!");
        }
        if (availableSlots <= 0) {
            throw new IllegalStateException("No available slots for this doctor!");
        }

        System.out.println("Doctor: " + getPerson().getName() + " "
                + getPerson().getSurname()
                + " is performing consultation on " + appointment);
        availableSlots--;
    }
}
