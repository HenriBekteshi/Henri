/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.bse1.hospitalsystem;

/**
 *
 * @author Bachelor
 */
public interface Schedulable {
    
    public AppointmentManager schedule(Patient patient, Doctor doctor, 
            String appDate);
    
    public AppointmentManager reschedule(String updatedDate);
}
