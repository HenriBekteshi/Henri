package com.mycompany.bse1.hospitalsystem;

public abstract class MedicalStaff {

    private Person person;
    private String department;

    public MedicalStaff(Person person, String department) {
        setPerson(person);
        setDepartment(department);
    }

    public MedicalStaff(String name, String surname, int age, String gender,
            String department) {
        this(new Person(name, surname, age, gender), department);
    }

    public Person getPerson() { return person; }

    public void setPerson(Person person) {
        if (person == null) {
            throw new IllegalArgumentException("Medical staff person cannot be null!");
        }
        this.person = person;
    }

    public String getDepartment() { return department; }

    public void setDepartment(String department) {
        if (department == null || department.trim().isEmpty()) {
            throw new IllegalArgumentException("Department cannot be null or empty!");
        }
        this.department = department.trim();
    }

    @Override
    public String toString() {
        return person + "\nDepartment : " + department;
    }

    public abstract void performDuty(AppointmentManager appointment);
}
