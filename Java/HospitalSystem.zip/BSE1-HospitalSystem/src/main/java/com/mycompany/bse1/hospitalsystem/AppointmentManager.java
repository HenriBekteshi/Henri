package com.mycompany.bse1.hospitalsystem;

public class AppointmentManager implements Schedulable {

    private String status;
    private String date;
    private Doctor assignedDoctor;
    private Patient patient;

    public AppointmentManager() {
    }

    @Override
    public String toString() {
        if (assignedDoctor != null && patient != null) {
            return "Appointment{" + "status=" + status + ", date=" + date
                    + ", patient=" + patient.getPerson() + ", doctor="
                    + assignedDoctor.getPerson() + '}';
        }
        return "Appointment{status=" + status + ", date=" + date
                + ", missing appointment data}";
    }

    public String getStatus() { return status; }

    public void setStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Status cannot be null or empty!");
        }
        this.status = status.trim();
    }

    public String getDate() { return date; }

    public void setDate(String date) {
        if (date == null || date.trim().isEmpty()) {
            throw new IllegalArgumentException("Date cannot be null or empty!");
        }
        this.date = date.trim();
    }

    public String getAssignedDoctor() {
        return assignedDoctor == null ? null : assignedDoctor.toString();
    }

    public Doctor getAssignedDoctorObject() {
        return assignedDoctor;
    }

    public void setAssignedDoctor(Doctor assignedDoctor) {
        if (assignedDoctor == null) {
            throw new MissingMedicalDataRuntimeException(
                    "Cannot create an appointment with missing doctor");
        }
        this.assignedDoctor = assignedDoctor;
    }

    public Patient getPatient() { return patient; }

    public void setPatient(Patient patient) {
        if (patient == null || patient.getPerson() == null) {
            throw new MissingMedicalDataRuntimeException(
                    "Cannot create an appointment with missing patient data");
        }
        this.patient = patient;
    }

    @Override
    public AppointmentManager schedule(Patient patient, Doctor doctor, String appDate) {
        if (patient == null || patient.getPerson() == null) {
            throw new MissingMedicalDataRuntimeException("Patient is required!");
        }
        if (doctor == null) {
            throw new MissingMedicalDataRuntimeException("Doctor is required!");
        }
        if (appDate == null || appDate.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment date is required!");
        }

        setPatient(patient);
        setAssignedDoctor(doctor);
        setDate(appDate);
        setStatus("SCHEDULED");
        return this;
    }

    @Override
    public AppointmentManager reschedule(String updatedDate) {
        if (patient == null || assignedDoctor == null) {
            throw new MissingMedicalDataRuntimeException(
                    "Cannot reschedule an incomplete appointment!");
        }
        setDate(updatedDate);
        setStatus("RESCHEDULED");
        return this;
    }
}
