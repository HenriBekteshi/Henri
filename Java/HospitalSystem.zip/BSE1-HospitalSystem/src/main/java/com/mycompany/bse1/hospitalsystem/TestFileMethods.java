package com.mycompany.bse1.hospitalsystem;

import java.io.File;
import java.io.IOException;

public class TestFileMethods {

    public static void main(String[] args) throws IOException {
        File peopleFile = FileManagementService.createPeopleFile(
                "HospitalData", "people.txt");

        FileManagementService.printFileInfo(peopleFile);

        File randomFile = new File("random.txt");
        FileManagementService.printFileInfo(randomFile);

        Person p1 = new Person("ann", "smith", 60, "F");
        FileManagementService.writePerson(peopleFile, p1, false);

        Person p2 = new Person("ben", "tom", 17, "M");
        FileManagementService.writePerson(peopleFile, p2, true);

        FileManagementService.readFile(peopleFile);
    }
}
