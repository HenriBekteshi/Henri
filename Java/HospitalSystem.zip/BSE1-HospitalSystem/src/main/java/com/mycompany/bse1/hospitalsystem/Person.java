package com.mycompany.bse1.hospitalsystem;

public class Person {

    private String name;
    private String surname;
    private int age;
    private String gender;

    public Person() {
    }

    public Person(String name, String surname, int age, String gender) {
        setName(name);
        setSurname(surname);
        setAge(age);
        setGender(gender);
    }

    public String getName() { return name; }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Person name cannot be null or empty!");
        }
        this.name = name.trim();
    }

    public String getSurname() { return surname; }

    public void setSurname(String surname) {
        if (surname == null || surname.trim().isEmpty()) {
            throw new IllegalArgumentException("Person surname cannot be null or empty!");
        }
        this.surname = surname.trim();
    }

    public String getGender() { return gender; }

    public void setGender(String gender) {
        if (gender == null || gender.trim().isEmpty()) {
            throw new IllegalArgumentException("Person gender cannot be null or empty!");
        }
        String value = gender.trim();
        if (value.equalsIgnoreCase("m") || value.equalsIgnoreCase("male")) {
            this.gender = "Male";
        } else if (value.equalsIgnoreCase("f") || value.equalsIgnoreCase("female")) {
            this.gender = "Female";
        } else {
            throw new IllegalArgumentException("Gender must be Male/Female or M/F!");
        }
    }

    public int getAge() { return age; }

    public void setAge(int age) {
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be greater than 0!");
        }
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", surname=" + surname
                + ", age=" + age + ", gender=" + gender + '}';
    }

    public String getFileLine() {
        return name + "," + surname + "," + age + "," + gender;
    }

    public String getUILine() {
        return name + "\t\t" + surname + "\t\t" + age + "\t\t" + gender;
    }
}
