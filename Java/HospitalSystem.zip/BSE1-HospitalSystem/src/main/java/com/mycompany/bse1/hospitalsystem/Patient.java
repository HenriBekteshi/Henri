package com.mycompany.bse1.hospitalsystem;

public class Patient {

    private Person person;

    public Patient() {
    }

    public Patient(Person person) {
        setPerson(person);
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        if (person == null) {
            throw new IllegalArgumentException("Patient person cannot be null!");
        }
        this.person = person;
    }

    public void setPerson(String name, String surname, int age, String gender) {
        if (this.person == null) {
            this.person = new Person(name, surname, age, gender);
        } else {
            this.person.setName(name);
            this.person.setSurname(surname);
            this.person.setAge(age);
            this.person.setGender(gender);
        }
    }

    public void display() {
        if (person == null) {
            System.out.println("Patient has no person data.");
            return;
        }
        System.out.println(person);
    }
}
