/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.bse1.hospitalsystem;

/**
 *
 * @author Bachelor
 */
public class BSE1HospitalSystem {

    public static void main(String[] args) {
        
        Person person1 = new Person();
        person1.setName("John"); //validate that null name cannot be set
        person1.setSurname("Smith");
        person1.setAge(8); //validate that negative age cannot be set
        person1.setGender("Male");
        System.out.println(person1.getName());
        
        //create a new person using parametrized constructor
        Person person2 = new Person("Ben", "Smith", 45, "MALE");
        System.out.println(person2.toString());
        
        //create a new patient
        Patient patient1 = new Patient();
        patient1.display();
        //set the person properties of the patient
        //patient1.setPerson("Sara", "Any", 67, "Female");
        
        
        //create and initialize new doctors
        String depSpecializationDoc1 = "Cardiology";
        Doctor docCardio = new Doctor("John", "Kim", 45, "M", 
                depSpecializationDoc1, depSpecializationDoc1, "Mon-Wed", 10);
        System.out.println(docCardio.toString());
        
        Person personDerma = new Person("June", "King", 38, "F");
        Doctor docDerma = new Doctor(personDerma, "General", "Dermatology",
                "Thur-Sat", 6);
        System.out.println(docDerma.toString());
        
        //create and initialize a patient with only a person
        Patient patient2 = new Patient(person2);
        patient2.display();
        AppointmentManager appointmentForDerma = new AppointmentManager();
        appointmentForDerma = 
                appointmentForDerma.schedule(patient2, docDerma, "25-12-2025");
        
        //create and initialize a person object and use it in the
        //constructor of a patient
        Patient patient3 = new Patient(
                new Person("Ann", "Soyer", 34, "FEMALE"));
        patient3.display();
        AppointmentManager appointment3ForCardio = new AppointmentManager();
        appointment3ForCardio.getAssignedDoctor();
        appointment3ForCardio =
            appointment3ForCardio.schedule(patient3, docCardio, "27-12-2025");
        appointment3ForCardio = appointment3ForCardio.reschedule("04-12-2025");
        
        docCardio.performDuty(appointment3ForCardio);
    }
}
