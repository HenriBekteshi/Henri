/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class SearchSortUtility {
    
    public static Integer[] searchNumeric(int[] array, int key){
        
        Integer[] matchedArr = new Integer[100];
        int matchedInd = 0;
        
        for(int i=0; i<=array.length-1; i++){
            
            if(array[i] == key){
                matchedArr[matchedInd] = i;
                matchedInd++;
            }
        }
        
        if(matchedInd == 0) return null;
        else return matchedArr;
    }
    
    public static Person[] sortPeople(Person[] people){
        
        for(int i=0; i<=people.length-2; i++){
            for(int j=0; j<=people.length-2-i; j++){
                Person current = people[j];
                Person next = people[j+1];
                
                if(current.getName().compareToIgnoreCase(next.getName()) > 0){
                    people[j] = next;
                    people[j+1] = current;
                }
            }
        }
        return people;
    }
}
