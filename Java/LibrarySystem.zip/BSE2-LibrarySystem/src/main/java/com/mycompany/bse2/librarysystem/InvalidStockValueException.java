/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
//define a custom runtime exception
public class InvalidStockValueException extends RuntimeException{
    
    public InvalidStockValueException(String message){
        super(message);
    }
}
