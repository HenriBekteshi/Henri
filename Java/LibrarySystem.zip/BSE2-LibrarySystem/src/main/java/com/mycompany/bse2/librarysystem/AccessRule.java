/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public interface AccessRule {
    
    public static final int AGE_RESTRICTION_E_BOOKS = 21;
    
    public boolean canAccess(int userAge);
}
