/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */ 
public class Author extends Person {  //this is a top level class
  
    private String zhanre;
    private String language;
    private boolean active;
    
    public Author(){}

    public Author(String name, String surname, 
            String zhanre, String language, boolean active) {
        //call the super constructor
        super(name, surname);
        this.zhanre = zhanre;
        this.language = language;
        this.active = active;
    }
    
    public void setZhanre(String zhanre){
        if(zhanre == null){
            throw new NullPointerException("Author zhanre cannot be null!");
        }
        else if(!zhanre.equalsIgnoreCase("Novels") && 
                !zhanre.equalsIgnoreCase("Poetry") && 
                !zhanre.equalsIgnoreCase("Comics") &&
                !zhanre.equalsIgnoreCase("Sci-Fi")){
            throw new IllegalArgumentException("Zhanre value not accepted!");
        }
        this.zhanre = zhanre;
    }
    
    public String getZhanre(){
        return this.zhanre;
    }
    
    public void setLanguage(String language){
        if(language == null){
            System.out.println("Author language cannot be null");
        }
        else{
            this.language = language;
        }
    }
    
    public String getLanguage(){
        return this.language;
    }
    
    public void setIsActive(boolean active){
        this.active = active;
    }
    
    public boolean getIsActive(){
        return this.active;
    }

    @Override
    public String toString() {
        return "Author{" + "name=" + this.getName() + ", "
                + "surname=" + this.getSurname() + ", zhanre=" 
                + zhanre + ", language=" + language 
                + ", active=" + active + '}';
    }
}