/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class TestSearchSortUtility {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //define an array
        int[] myArray = {100, 12, 35, 35, 100, 2};
        
        //call searchNumeric using key present in the array
        Integer[] matched = SearchSortUtility.searchNumeric(myArray, 100);
        //print results
        printResult(matched, false);
        
        //call searchNumeric using key not present in the array
        matched = SearchSortUtility.searchNumeric(myArray, 10001);
        //print results
        printResult(matched, false);
        
        Person p1 = new Person("xhorxh", "andoni");
        Person p2 = new Person("albi", "doda");
        Person p3 = new Person("klejdi", "hyseni");
        Person[] people = {p1, p2, p3};
        people = SearchSortUtility.sortPeople(people);
        printResult(people, true);
        
    }
    
    private static void printResult(Object[] matchedArray, boolean sort){
        if(matchedArray == null){
            System.out.println("No matches found");
        }
        else{
             if(sort) System.out.print("Sorted array: ");
             else System.out.print("Mtached array: ");
             for(Object i : matchedArray){
                 if(i!=null){
                     System.out.print(i + "  ");
                 }
             }
        }
        System.out.print("\n");
    }
    
}
