/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bachelor
 */
public class FileManagementUtility {
    
    public static File createPeopleFile(String directoryName, String fileName) 
            throws IOException{
        
        File directory = new File(directoryName);
        if(!directory.exists()){
            boolean createdDir = directory.mkdir();
            System.out.println("Creating a new directory: " + createdDir + "\n");
        }
        
        File file = new File(directoryName, fileName);
        if(!file.exists()){
            boolean createdFile = file.createNewFile();
            System.out.println("Creating a new file: " + createdFile + "\n");
        }
        
        return file;
    }
    
    public static void printFileInfo(File file){
        if(file.exists()){
           System.out.println("File absolute path: " + file.getAbsolutePath());
           System.out.println("File name: " + file.getName());
           System.out.println("File size: " + file.length());
           System.out.println("File Read permissions: " + file.canRead());
           System.out.println("File Write permissions: " + file.canWrite() + "\n");
        }
        else{
            System.out.println("File doesn't exist\n" + file);
        }
    }
    
    public static void writePerson(File file, Person person, boolean append)
            throws IOException{
        if(file.exists()){
            String inputText = person.getFileLine();
            
            FileWriter fw = new FileWriter(file, append);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(inputText);
            bw.newLine();
            bw.close();
            System.out.println("Wrote person to file\n");
        }
        else{
            System.out.println("File doesn't exist\n" + file);
        }
    }
    
    public static Person[] readAndPrintPeople(File file) 
            throws FileNotFoundException, IOException{
        if(file.exists()){
            
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            Person[] peopleAray = new Person[10];
            int index = 0;
            String personLine;
            while((personLine = br.readLine()) != null){
                
                String[] personArray = personLine.split(",");
                Person person = new Person(personArray[0], personArray[1]);
                peopleAray[index]= person;
                index++;
                //System.out.println(person.toString());
            }
            return peopleAray;
        }
        else{
            System.out.println("File doesn't exist\n" + file);
        }
        return null;
    }
}
