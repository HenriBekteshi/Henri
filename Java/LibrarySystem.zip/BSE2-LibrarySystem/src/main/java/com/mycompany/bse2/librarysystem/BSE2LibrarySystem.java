/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class BSE2LibrarySystem {

    public static void main(String[] args) {
        
        Author authorKadare = new Author();
        authorKadare.setName("Ismail");
        authorKadare.setSurname("Kadare");
        authorKadare.setZhanre("comics"); //check zhanre validation is working
        authorKadare.setLanguage("Albanian");
        authorKadare.setIsActive(false);
        System.out.println(authorKadare.getName());
        
        Author authorAgolli = new Author("Dritero", "Agolli", "poetry",
                           "Albanian", false);
        System.out.println(authorAgolli.toString());
        
        // creates empty object
        Book book1 = new Book();
        book1.setTitle("Kronike ne gur");
        //book1.setAuthor(authorKadare);
        book1.setPrice(10.3f);
        book1.setStock(10);
        book1.displayData();
        
        Book keshtjellaBook = new Book("Keshtjella", authorKadare);
        keshtjellaBook.displayData();
        keshtjellaBook.populateStock(15.25f, 45);
                
        Book prideBook = new Book("Pride and Prejudice", 
                new Author("Jane", "Austen", "Novels", "English", false),
                10.25f, 10);
        prideBook.displayData();
        //prideBook.populateStock(-10, 15);
        prideBook.addDiscount(null, 5f);
        prideBook.addDiscount("FIXED", 5f);
        
        keshtjellaBook.sellBook();
        keshtjellaBook.displayData();
        
        keshtjellaBook.addDiscount("FIXED", 5.0f);
        keshtjellaBook.sellBook();
        
        Book ebook1 = new EBook("Keshtjella", authorKadare, 15f, "PDF", 200);
        EBook ebook2 = new EBook("Kronike ne Gur", authorKadare, 20.5f, "PDF", 150);
        
        ebook1.displayData();
        ebook2.displayData();
        
        ebook2.addDiscount("PERCENTAGE", 0.15f);
        
        ebook1.addDiscount("FIXED", 5f);
        ebook1.applyDiscount();
        
        LocalSupplier botimeOnufri = new LocalSupplier(
                "Shtepia botuese Onfuri",
                "botimeonufri@gmail.com", 
                "Tirane, Albania");
        botimeOnufri.display("Local");
        botimeOnufri.supplyBooks();
        
        InternationalSupplier ingramGroup = new InternationalSupplier(
                "Ingram Content Group",
                "ingramgroup@yahoo.com",
                "London, UK",
                true,
                8);
        ingramGroup.display("International");
        ingramGroup.supplyBooks();
        
        
        //create 1 book of zhanre Comics
        //create 1 book of zhanre Sci-Fi
        // in both cases verify access for user age 17
        Author authorComics = new Author("Jeff", "Kirby", 
                "comics", "English", false);
        Author scifiAuthor = new Author("Geroge", "Orwell", 
                "Sci-fi", "English", true);

        Book comics = new Book("Superman", authorComics, 10.25f, 10);
        Book sciFi = new Book("1984", scifiAuthor, 25f, 15);
        
        System.out.println("User can access Book: " + comics.getTitle() + ": " +
                comics.canAccess(17));
        
        System.out.println("User can access Book: " + sciFi.getTitle() + ": " +
                sciFi.canAccess(17));
        
        System.out.println("User can access EBook: " + ebook1.getTitle() + ": " +
                ebook1.canAccess(17));
        System.out.println("User can access EBook: " + ebook2.getTitle() + ": " +
                ebook2.canAccess(24));
    }
}
