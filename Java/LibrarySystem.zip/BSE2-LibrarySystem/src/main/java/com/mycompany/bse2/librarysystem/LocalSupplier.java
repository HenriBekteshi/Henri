/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class LocalSupplier extends Supplier{
    
    public LocalSupplier(String name, String email, String address){
        super(name, email, address);
    }
    
    @Override
    public void supplyBooks(){
        System.out.println("Books can be supplied within today.");
    }
    
}
