/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class InternationalSupplier extends Supplier{
    
    private boolean customProcessingIncluded;
    private int deliveryDays;
    
    public InternationalSupplier(String name, String email, String address,
            boolean customProcessingIncluded, int deliveryDays){
        super(name, email, address);
        this.customProcessingIncluded = customProcessingIncluded;
        this.deliveryDays = deliveryDays;
    }

    public boolean isCustomProcessingIncluded() {
        return customProcessingIncluded;
    }

    public void setCustomProcessingIncluded(boolean customProcessingIncluded) {
        this.customProcessingIncluded = customProcessingIncluded;
    }

    public int getDeliveryDays() {
        return deliveryDays;
    }

    public void setDeliveryDays(int deliveryDays) {
        this.deliveryDays = deliveryDays;
    }
    
    @Override
    public void supplyBooks(){
        
        if(!customProcessingIncluded){
            System.out.println("Books can be supplied within "+
                    this.deliveryDays +".");
        }
        else{
            System.out.println("Books can be supplied within "+
                    (this.deliveryDays + 5) +" days.");
        }
    }
}
