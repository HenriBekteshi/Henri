/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author Bachelor
 */
public class TestFileManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        
        File peopleFile = FileManagementUtility.createPeopleFile(
                "C:\\Users\\Bachelor\\Documents\\Data\\LibraryData", "people.txt");
        FileManagementUtility.printFileInfo(peopleFile);
        
        File random = new File("RANDOM.TXT");
        FileManagementUtility.printFileInfo(random);
        
        Person p1 = new Person("bse", "software");
        FileManagementUtility.writePerson(peopleFile, p1, true);
        
        Person p2 = new Person("cen", "computer");
        FileManagementUtility.writePerson(peopleFile, p2, true);
        
        Person[] peopleList = FileManagementUtility.readAndPrintPeople(peopleFile);
        
        for(Person p : peopleList){
            System.out.println(p.toString());
        }
        
    }
    
}
