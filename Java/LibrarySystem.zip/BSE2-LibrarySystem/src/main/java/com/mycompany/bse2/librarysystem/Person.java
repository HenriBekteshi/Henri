/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class Person {
    
    private String name;
    private String surname;

    public Person(){}
    
    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public void setName(String name){
        if(name == null){
            throw new NullPointerException("Person name cannot be null!");
        }
        this.name = name;
    }
    
    public void setSurname(String surname){
        if(surname == null){
            throw new NullPointerException("Person surname cannot be null!");
        }
        this.surname = surname;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", surname=" + surname + '}';
    }
    
    public String getFileLine(){
        return this.name + "," + this.surname;
    }
    
    public String getUILine(){
        return this.name + " \t\t\t" + this.surname;
    }
}
