/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bse2.librarysystem;

/**
 *
 * @author Bachelor
 */
public class EBook extends Book{
    
    private String format;
    private int size;
    
    public EBook(String title, Author author, float price,
            String format, int size){
        super(title, author, price, 0);
        this.format = format;
        this.size = size;
    }
    
    public void setFormat(String format){
        this.format = format;
    }
    
    public String getFormat(){
        return this.format;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
    @Override
    void displayData(){
        System.out.println("Book " + this.getTitle() + " is written by "
                + this.getAuthor().toString() + ". \nPrice: " + this.getPrice() +
                "\nISBN: " + this.getIsbn() +
                "\nFile format: " + this.format +
                "\n File sinze in MB: " + this.size);
        
        System.out.println("________________________________");
    }
    
    @Override
    public void addDiscount(String type, float amount){
        
        if(type != null && type.equals("PERCENTAGE")){
            this.setDiscount(type, amount);
        }
        else{
            System.out.println("The only allowed discount type is percentage");
        }
    }
    
    @Override
    public boolean canAccess(int userAge){
        
        return userAge >= AccessRule.AGE_RESTRICTION_E_BOOKS;
    }
}
