/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class Person { //this is a top level class
    
    private String name;
    private String surname;
    private String id;
    
    public Person(){}
    
    public Person(String name, String surname, String id){
        this.name = name;
        this.surname = surname;
        this.id = id;
    }
    
    public void setName(String name){
        
        if (name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("The name cannot be null or empty!");
        }
        this.name = name;
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setSurname(String surname){
        
        if (surname == null || surname.trim().isEmpty()){
            throw new IllegalArgumentException("The surname cannot be null or empty!");
        }
        this.surname = surname;
    }
    
    public String getSurname(){
        return this.surname;
    }
    
    public void setId(String id){
        
        if (id == null || id.trim().isEmpty()){
            throw new IllegalArgumentException("The ID cannot be null or empty!");
        }
        this.id = id;
    }
    
    public String getId(){
        return this.id;
    }
    
    public String display(){
        return this.name + " " + this.surname;
    }
    
    public String getFileLine(){
        return this.id + "," + this.name + "," + this.surname;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", surname=" + surname + ", id=" + id + '}';
    }
    
    public String getUIRepr(){
        return this.id + " \t\t" + this.name + " \t\t" + this.surname; 
    }
}
