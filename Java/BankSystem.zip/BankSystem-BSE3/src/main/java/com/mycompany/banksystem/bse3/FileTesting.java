/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.banksystem.bse3;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author Bachelor
 */
public class FileTesting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        File peopleFile = FileManagementUtility.createPeopleFile(
                "ProjectData/BSE3", "peopleData.txt");
        FileManagementUtility.printFileInfo(peopleFile);
        
        //create a new file
        File randomFile = new File("randomfile.txt");
        FileManagementUtility.printFileInfo(randomFile);
        
        FileManagementUtility.readLineByLine(peopleFile);
        
        Person p1 = new Person("ann", "smith", "676dyugsjus");
        FileManagementUtility.writePerson(peopleFile, p1, true);
        
        Person p2 = new Person("ben", "thompson", "dshjubhs789s");
        FileManagementUtility.writePerson(peopleFile, p2, false);
        
        System.out.println("\nReading line by line:");
        FileManagementUtility.readLineByLine(peopleFile);
        
        System.out.println("\nReading as people objects:");
        FileManagementUtility.readPeople(peopleFile);
    }
    
}
