/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public abstract class Employee {
    
    private Person personInfo;
    private String id;

    public Employee(Person personInfo, String id) {
        setPersonInfo(personInfo);
        setId(id);
    }
    
    public Employee(String personName, String personSurname, String personId,
            String employeeId){
        this.personInfo = new Person(personName, personSurname, personId);
        this.id = employeeId;
    }

    public Person getPersonInfo() {
        return personInfo;
    }

    public void setPersonInfo(Person personInfo) {
        if(personInfo == null) 
            throw new NullPointerException("Employee person information cannot be null!");
        this.personInfo = personInfo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if(id == null) throw new NullPointerException("Employee ID cannot be null!");
        this.id = id;
    }
    
    public abstract boolean authorizeOperation(Transaction transaction);
    
}
