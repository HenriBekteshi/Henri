/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
//
public class SavingAccount extends BankAccount 
        implements TransactionApprovalRule{  //implement the interface to define transaction approval rules
    
    private float interestRate;
    
    public SavingAccount(Person owner, String accountId, 
            float balance, float interestRate){
        super(owner, accountId, balance);
        this.interestRate = interestRate;
    }
    
    public float getInterestRate(){
        return this.interestRate;
    }
    
    public void setInterestRate(float interestRate){
        
        if (interestRate >= 0.0f && interestRate <= 1.0f){
            this.interestRate = interestRate;
        }
        else{
            System.out.println("The interest rate should be between"
                    + " 0 - 1.");
        }
    }
    
    @Override
    public void display(){
        System.out.println(this.getOwner().display() + " has account with ID: " +
               this.getAccountId() +  " and balance of: " +
               this.getBalance() + ". Interest rate for the saving"
                       + "account is: " + this.interestRate + ".");
    }
    
    @Override
    public Transaction deposit(float amount, String date){
        
        boolean approved = approve(amount, "SAVING DEPOSIT");
        
        if(!approved){
            System.out.println("Deposit dated "+ date +" cannot be approved");
            return null;
        }
        else{
            float interestAmount = (this.getBalance() + amount) * this.interestRate;
            float totalDeposit = amount + interestAmount;
            this.setBalance(this.getBalance() + totalDeposit);
            
            Transaction transaction = new Transaction("SAVING DEPOSIT", 
                    totalDeposit, this.getBalance(), date, this);
            
            System.out.println(transaction.toString());
            return transaction;
        }
   }

    @Override
    public boolean approve(float amount, String operationType) {
        
        if(operationType.equals("SAVING DEPOSIT") && amount > 0.0f &&
                TransactionApprovalRule.TRANSACTION_LIMIT_MIN <= amount){
            return true;
        } 
        else{
            return false;
        }
    }
}
