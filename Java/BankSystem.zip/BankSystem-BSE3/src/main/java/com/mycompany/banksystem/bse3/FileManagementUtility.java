/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Bachelor
 */
public class FileManagementUtility {
    
    //1
    public static File createPeopleFile(String directoryName, String fileName) throws IOException{
        
        File directory = new File(directoryName);
        if(!directory.exists()){
            boolean createdDir = directory.mkdirs();
            System.out.println("Trying to create a directory: " + createdDir);
        }
        
        File file = new File(directoryName, fileName);
        if(!file.exists()){
            
            boolean createdFile = file.createNewFile();
            System.out.println("Trying to create a file: " + createdFile);
        }
        
        return file;
    }
    
    //2
    public static void printFileInfo(File file){
        if(file.exists()){
           System.out.println("File absolute path: " + file.getAbsolutePath());
           System.out.println("File name: " + file.getName());
           System.out.println("File size: " + file.length());
           System.out.println("File Read permissions: " + file.canRead());
           System.out.println("File Write permissions: " + file.canWrite());
        }
        else{
            System.out.println("File doesn't exist");
        }
    }
    
    //3
    public static void readLineByLine(File file) throws FileNotFoundException, IOException{
       if(file.exists()){
         
           System.out.println("Reading file: " + file.getName());
           try (BufferedReader br = new BufferedReader(new FileReader(file))) {
               String line;
               while((line = br.readLine()) != null){
                   System.out.println(line);
               }
           }
       }
       else{
            System.out.println("File doesn't exist");
        }
    }
    
    public static void writePerson(File file, Person person, boolean withOverwrite) 
            throws IOException{
        if(file != null && file.exists() && person != null){
            String personLine = person.getFileLine();
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, !withOverwrite));
            bw.write(personLine);
            bw.newLine();
            
            bw.close();
        }
        else{
            System.out.println("File doesn't exist");
        }
    }
    
    public static Person[] readPeople(File file) throws FileNotFoundException, IOException{
       if(file.exists()){
         
           System.out.println("Reading file: " + file.getName());
           java.util.List<Person> people = new java.util.ArrayList<>();
           try (BufferedReader br = new BufferedReader(new FileReader(file))) {
               String line;
               while((line = br.readLine()) != null){
                   String[] personArray = line.split(",", -1);
                   if(personArray.length != 3){
                       System.out.println("Skipping malformed line: " + line);
                       continue;
                   }
                   Person person = new Person(personArray[1].trim(), personArray[2].trim(), personArray[0].trim());
                   people.add(person);
                   System.out.println(person.toString());
               }
           }
           return people.toArray(new Person[0]);
       }
       else{
            System.out.println("File doesn't exist");
            return null;
       }
    }
}

