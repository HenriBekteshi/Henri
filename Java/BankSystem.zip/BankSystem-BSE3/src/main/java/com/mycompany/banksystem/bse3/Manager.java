/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class Manager extends Employee{
    
    private String department;
    
    public Manager(Person personInfo, String id, String department){
        super(personInfo, id);
        this.department = department;
    }
    
    public Manager(String personName, String personSurname, String personId,
            String employeeId, String department){
        super(personName, personSurname, personId, employeeId);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }


    @Override
    public boolean authorizeOperation(Transaction transaction){
        return true;
    }
}
