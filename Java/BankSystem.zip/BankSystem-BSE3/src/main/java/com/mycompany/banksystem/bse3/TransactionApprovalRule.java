/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */

//define an interface to define approval behavior
public interface TransactionApprovalRule {
    
    public static final float TRANSACTION_LIMIT_MIN = 5000f;
    
    public boolean approve(float amount, String operationType);
    
}
