/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class LoanAccount extends BankAccount 
        implements TransactionApprovalRule{ //implement the interface to define transaction approval rules

    private float loanAmount;
    private float monthlyPayment;

    public LoanAccount(Person owner, String accountId,
            float loanAmount, float monthlyPayment) {
        super(owner, accountId, 0.0f);
        this.loanAmount = validateLoanAmount(loanAmount);
        this.setBalanceLoanAccount(-this.loanAmount);
        this.monthlyPayment = validateMonthlyPayment(monthlyPayment);
    }

    public float getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(float loanAmount) {
        if(loanAmount <= 0.0f){
            throw new IllegalArgumentException("Loan amount must be greater than zero!");
        }
        this.loanAmount = loanAmount;
    }

    public float getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(float monthlyPayment) {
        if (monthlyPayment <= 0.0f){
            throw new IllegalArgumentException("Monthly payment must be greater than zero!");
        }
        this.monthlyPayment = monthlyPayment;
    }
    private static float validateLoanAmount(float loanAmount){
        if(loanAmount <= 0.0f){
            throw new IllegalArgumentException("Loan amount must be greater than zero!");
        }
        return loanAmount;
    }

    private static float validateMonthlyPayment(float monthlyPayment){
        if(monthlyPayment <= 0.0f){
            throw new IllegalArgumentException("Monthly payment must be greater than zero!");
        }
        return monthlyPayment;
    }
    
    @Override
    public void display(){
       System.out.println(this.getOwner().display() + " has account with ID: " +
               this.getAccountId() +  ". Has taken a loan amount of: " +
               this.loanAmount + ", with monthly payments of " +
                       this.monthlyPayment + " ALL.");
    }
    
    //used to repay the loan by a dynamic ammount besides the monthly payment
    
    @Override
    public Transaction withdraw(float amount, String date){
        boolean approved = approve(amount, "Loan Payment");
        if(approved){
            //update the palance, so the amount repays the loan
            float newBalance = this.getBalance() + amount;
            this.setBalanceLoanAccount(newBalance);
            
            Transaction transaction = new Transaction("Loan Payment", amount, 
                    newBalance, date, this);
            
            //print transaction
            System.out.println(transaction.toString());
            return transaction;
        }
        else{
            System.out.println("Loan repayment dated: " + 
                    date + " cannot be approved!");
            return null;
        }
    }
    
    public void payLoan(String date){
        this.withdraw(this.monthlyPayment, date);
    }

    @Override  //implement the TransactionApprovalRule methods
    public boolean approve(float amount, String operationType) {
        if(operationType.equals("Loan Payment") && amount > 0.0f && 
                amount <= this.monthlyPayment && this.getBalance() < 0){
            return true;
        }
        else{
            return false;
        }
    }
}
