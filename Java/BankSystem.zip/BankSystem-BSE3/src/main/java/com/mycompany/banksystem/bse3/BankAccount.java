/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class BankAccount { //this is a top level class
    
    private Person owner;   //using Person object defined in another class as data type
    private String accountId;
    private float balance;
    
    public BankAccount() {} // default no-parameter constructor
    
    public BankAccount(Person owner, String accountId, float balance){
       setOwner(owner);
       setAccountId(accountId);
       setBalance(balance);
   }
    
    // getters and setters for each private class field
    public void setOwner(Person owner){
        
        if(owner == null){ //validating the owner to be different from null by throwing an exception
            throw new NullPointerException("Owner of the banck account cannot"
                    + " be null!");
        }
        else{
           this.owner = owner; 
        }
    }
    
    public String getOwnerString(){
        //if the owner is null the call to display() method will fail 
        //hence we surround using try and catch blok to decide how to handle
        //any exception caught
        try{
          return this.owner.display();  
        }
        catch (NullPointerException e){
            System.out.println("CAUGHT EXCEPTION: " + e.getMessage()); //prints the error of the exception encountered
            throw e; //throws the exception encountered
        }
    }
    
    public Person getOwner(){
        return this.owner;
    }
    
    public void setAccountId(String accountId){
        if(accountId == null || accountId.trim().isEmpty()){
            throw new IllegalArgumentException("Account ID cannot be null or empty!");
        }
        this.accountId = accountId;
    }
    public String getAccountId(){
        return this.accountId;
    }
    
    public float getBalance(){
        return this.balance;
    }
    
    public void setBalanceLoanAccount(float balance){
        this.balance = balance;
    }
    
    public void setBalance(float balance){
        if(balance < 0.0f){
            throw new IllegalArgumentException("Account balance cannot be negative!");
        }
        this.balance = balance;
    }
    
    public void display(){
        
        // add a
       
        // call the Person object display method within the display of BankAccount
       System.out.println(this.owner.display() + " has account with ID: " +
               this.accountId +  " and balance of: " +
               this.balance + ".");
    }
   
    public Transaction deposit(float amount, String date){
        
        if(amount <= 0.0f || amount < TransactionApprovalRule.TRANSACTION_LIMIT_MIN){
            System.out.println("Deposit amount is not sufficient");
            return null;
        }
        else{
            this.balance += amount;
            
            // only create a transaction object on successful deposit
            Transaction currentTransaction = new Transaction("Deposit", 
                    amount, this.balance, date, this);
            System.out.println(currentTransaction.toString());
            return currentTransaction;
        }
   }
   
    public Transaction withdraw(float amount, String date){
        
        if(amount <= 0.0f){
            throw new IllegalArgumentException("Withdrawal amount must be greater than zero!");
        }

        // throw custom user defined exception
        if(this.balance < amount){
            throw new NotEnoughFundsException("Not enough funds to withdraw!");
        }

        this.balance -= amount;
        // only create a transaction object on successful withdrawal
         Transaction currentTransaction = new Transaction("Withdraw", 
                 amount, this.balance, date, this);
         System.out.println(currentTransaction.toString());
         return currentTransaction;
       
    }
}
