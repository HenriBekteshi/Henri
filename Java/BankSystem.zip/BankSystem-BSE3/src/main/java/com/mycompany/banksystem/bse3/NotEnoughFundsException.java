/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */

//custom exception definition
public class NotEnoughFundsException extends RuntimeException{

    public NotEnoughFundsException(String message) {
        super(message);
    }
       
}
