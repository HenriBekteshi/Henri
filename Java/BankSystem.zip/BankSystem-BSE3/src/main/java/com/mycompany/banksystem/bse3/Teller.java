/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class Teller extends Employee{
    
    public Teller(Person personInfo, String id, String department){
        super(personInfo, id);
    }
    
    public Teller(String personName, String personSurname, String personId,
            String employeeId){
        super(personName, personSurname, personId, employeeId);
    }
    
    @Override
    public boolean authorizeOperation(Transaction transaction){
        
        if(transaction == null) return false;
        
        float transactionAmount = transaction.getAmount();
        if(transactionAmount <= 500.0f){
            return true;
        }
        return false;
    }
}
