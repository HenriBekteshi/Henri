/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.banksystem.bse3;

/**
 *
 * @author Bachelor
 */
public class BankSystemBSE3 {

    public static void main(String[] args) {
        
        //create and initialize a person object, using no args constructor
        Person person = new Person();
        person.setName("Ann");
        person.setSurname("Smith");
        person.setId("dhusi7878373ds");
        System.out.println(person.display());
       
        //create and initialize a BankAccount object using parametrized constructor
        BankAccount account1 = new BankAccount(person, 
                "27189e3nhdiode", 250000f);
        
        BankAccount account2 = new BankAccount();
        
        //initialize and create a person object to associate with a BankAccount object
        account2.setOwner(new Person("Ben", "Smith", "37283hjhsjd3"));
        account2.setAccountId("gdaui892819gs");
        account2.setBalance(10000.0f);
        
        account2.withdraw(6700.0f, "05-11-2025");
        account2.deposit(500.0f, "26-11-2025");
        
        account2.deposit(1250000.0f, "05-11-2025");
        Transaction withdrawAccount2 = account2.withdraw(400.0f, "05-11-2025");
        
        BankAccount savingAccountSuper = new SavingAccount(person,
            "dshyd67hgs", 840000f, 0.02f);
        savingAccountSuper.display();
        
        SavingAccount savingAccount = new SavingAccount(
            new Person("BSE 3", "CIT", "789890"),
            "dyh9878hjs", 1050000f, 0.2f);
        savingAccount.display();
        savingAccount.deposit(55000f, "12-11-2025");
        savingAccount.deposit(-55000f, "26-11-2025");
        Transaction depositTransaction =
                savingAccount.deposit(4800f, "26-11-2025");
        
        Person loanPerson = new Person("John", "DOE", "fwerf345sa");
        LoanAccount loanAccount = new LoanAccount(
                loanPerson, "e3289ja133", 5500000f, 10000f);
        loanAccount.display();
        loanAccount.payLoan("19-11-2025");
        loanAccount.payLoan("19-11-2025");
        Transaction withdrawTransaction = 
                loanAccount.withdraw(5000f, "26-11-2025");
        
        
        //create a Manager object
        Manager manager = new Manager("Kim", "Pearce", "26167267bdxw", 
                "empl719hdef", "LOAN");
        //call method authorizeOperation and print result
        System.out.println(manager.authorizeOperation(withdrawTransaction));
        
        
        //create a Teller object
        Teller teller = new Teller("Kim", "Pearce", "26167267bdxw", 
                "empl719hdef");
        //call method authorizeOperation and print result
        System.out.println(teller.authorizeOperation(depositTransaction));
        System.out.println(teller.authorizeOperation(withdrawAccount2));
        
        // testing exceptions safely
        BankAccount testException = new BankAccount();
        try {
            testException.getOwnerString();
        } catch (NullPointerException ex) {
            System.out.println("Expected exception: " + ex.getMessage());
        }
    }
}
